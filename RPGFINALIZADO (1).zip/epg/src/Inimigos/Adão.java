/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inimigos;

import java.awt.Image;
import javax.swing.ImageIcon;
import rpg.personagem.Personagem;

/**
 *
 * @author Filhos
 */
public class Adão extends Personagem {
    //mesmo os inimigos não sendo jogaveis suas caracteristicas são bem semelhan-
    //tes ao dos personagens jogaveis, então usa-se apenas a extensão Personagem
    //cada personagem terá o nome único e a imagem dele associado
    Image Ad;
    public Adão(){
        super(40,10,20);
        Ad=new ImageIcon("Imagens/arael.png").getImage();
        this.setNível(5);
        this.adicionarExp(50);
    }
    public Image getImage(){
         return Ad;
     }
    
}