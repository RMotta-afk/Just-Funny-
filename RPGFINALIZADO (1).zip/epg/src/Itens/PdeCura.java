/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Itens;

import rpg.personagem.Personagem;

/**
 *
 * @author Filhos
 */
public class PdeCura{
    //O item que será ganho apôs acessar o baú no mapa, serve para recuperar a vida
    int cura=30;
    int n;
    public PdeCura(Personagem p){
        //esse construdor acessara o valor da vida do personagem e curar ele
        this.n = p.getVida();
       this.n+=cura;
       p.setVida(this.n);
    }
}
