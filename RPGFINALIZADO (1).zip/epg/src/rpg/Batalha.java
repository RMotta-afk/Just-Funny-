/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg;
import Classes.Arqueiro;
import java.util.Random;
import java.util.Scanner;
import rpg.personagem.Personagem;
/**
 *
 * @author Filhos
 */
public class Batalha {
    //classe que implementará o codigo de batalha no jogo;
     static int ataqueJ(){
         //opções de ataque mostrada com println e um leitor scanner para saber 
         //qual ataque ira ser utilizado
        Scanner leitor = new Scanner(System.in);
        System.out.println("Selecione o ataque");
         System.out.println("1-Golpe");
          System.out.println("2-Especial, custa 10 de magia.");
        return leitor.nextInt();
    }
    
    static int ataqueI(){
        //aleatoriedade definida entre 1 e 2 para o ataque do inimigo
        Random gerador = new Random();
        return gerador.nextInt(2)+1;//retorna numero entre 1 e 2
    }
    
     static void imprimeVida(Personagem p, Personagem p2){
         //metodo para imprimir as informações dos personagens envolvidos
         System.out.println("Vida do Jogador:"+p.getVida());
        System.out.println("Pontos de Magia:" +p.getMagia());
        System.out.println("Dano:"+ p.getDano());
        System.out.println("Nível:"+p.getNível());
        System.out.println("experiência:" +p.getExp());
        System.out.println("\nVida do inimigo:"+p2.getVida());
        System.out.println("Pontos de Magia:" +p2.getMagia());
        System.out.println("Nível:"+p2.getNível());
     }
    //metodo da batatalha
    public static void batalha(Personagem J,Personagem I){
        //parametros que pegam as informações dos personagens
        int vida =J.getVida();
        int nivel=J.getNível();
        int magia=J.getMagia();
        int magiaO=I.getMagia();
        int nivelbot= I.getExp();
        int vidaBot= I.getVida();
        int exp= J.getExp();
        int expganho = I.getExp() ;
        int escolhaAtaque;
        

           while(vida>0 && vidaBot >0){
            //primeiro imprime o nome do inimigo
            System.out.println(I.getNome()+"\n");
            //depois chama o metodo para imprimir as informações gerais
            imprimeVida(J,I);
            //e define o int escolha ataque como o metodo que retorna o valor do scanner
            escolhaAtaque = ataqueJ();
            //o swich case que vai fazer o jogo acontecer
            switch(escolhaAtaque){
                case 1:
                    System.out.println("Jogador deu um golpe no inimigo");
                    //o dano aumenta conforme o nivel aumenta
                    vidaBot -= J.getDano();
                    break;
                case 2:
                    if(magia<10){
                        System.out.println("Pontos de Magia insuficiente!");
                        escolhaAtaque= 1;
                    }
                    else{
                        System.out.println("Jogador lançou sua habilidade sobre o inimigo");
                        magia-=10;
                         //O especial é mais poderoso que o ataque base e gasta MP
                        vidaBot -= J.getDano() + 20*nivel;
                    }
                    break;
                default:
                    while(escolhaAtaque!=1 && escolhaAtaque!=2){
                        System.out.println("Opção invalida");
                        escolhaAtaque= ataqueJ();
                    }
                    break;
            }
            if(vidaBot>0){
                //aqui define o ataque como o metodo de aleatoriedade de antes
                escolhaAtaque = ataqueI();
               switch(escolhaAtaque){
                case 1:
                    //como o inimigo não sobre de nível o valor do ataque é constante
                    System.out.println("inimigo deu um golpe no jogador");
                    vida -= I.getDano();
                    break;
                case 2:
                    if(magiaO<10){
                        escolhaAtaque=1;
                    }
                    else{
                     System.out.println("inimigo lançou sua habilidade sobre o jogador");
                    //e o especial é aumentado por um valor fixo
                    vida -= I.getDano()+10;
                    magiaO-=10;
                    }
                    break;
                default:
                    System.out.println("Opção invalida");
                    break;
            }
               I.setVida(vidaBot);
               I.setMagia(magiaO);
            }
            if(vida>0 && vidaBot<1){
                System.out.println("inimigo derrotado");
                //metodo que adiciona a experiencia do personagem
                J.adicionarExp(I.getExp());
               }
            if(vida<0){
                System.out.println("Você perdeu");
            }
            //função basica com if que aumenta o nivel
             if(J.getExp()>nivel*25){
             nivel++;
             J.setNível(nivel);
             magia=J.getMagia()+nivel*10;
             }
             //ultimo set vida para ficar salvo os danos sofridos na batalha
             J.setVida(vida);
             J.setMagia(magia);
        }
}
}