/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg.Jogo;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.ImageIcon;


/**
 *
 * @author Filhos
 */
public class PersonaInimigo {
     private int d;
    private int x;
    private int y;
    private int w;
    private int h;
    private Image image;
    private Rectangle r;
    //um temporizador para controlar a movimentação do inimigo
    private Timer t = new Timer();
    private long delay=100, intervalo=800;

    Random a = new Random();

    public PersonaInimigo(int dx, int dy) {
        x=dx;
        y=dy;

        loadImage();
        r= new Rectangle(x,y,w,h);
        //aleatoriedade que muda em intervalos para onde o inimigo vai
        t.scheduleAtFixedRate(new TimerTask() {
        public void run() {
            d=a.nextInt(4)+1;
        }
    }, delay, intervalo);     
    }

    private void loadImage() {
        
        ImageIcon ii = new ImageIcon("Imagens/arael.png");
        image = ii.getImage(); 
        
        w = image.getWidth(null);
        h = image.getHeight(null);
    }
    
//metodo a melhorar
// a partir dos numeros obtidos no metodo acima, o inimigo se move para determi-
//nada direção
    public void move() {
        
           
        if(d==1){
            x+=1;
            y+=0;
            
        }
        if(d==2){
            x+=0;
            y+=1;
        }
        if(d==3){
            x+=-1;
            y+=0;
        }
        if(d==4){
            x+=0;
            y+=-1;
        }
        if(x<0){
            x=0;
        }
        if(y>520){
            y=520;
        }
        if(x>520){
            x=520;
        }
        if(y<0){
            y=0;
        }
    }

    public int getX() {
        
        return x;
    }
    public void setX(int X){
        x=X;
    }

    public int getY() {
        
        return y;
    }
    public void setY(int Y){
        y=Y;
    }
    
    public int getWidth() {
        
        return w;
    }
    public void setWidth(int W){
        w=W;
    }
    
    public int getHeight() {
        
        return h;
    }
    public void setHeight(int H){
        h=H;
    }    

    public Image getImage() {
        
        return image;
    }
    public void setimage(Image I){
        image=I;
    }
    //metodo que desenha o personagem no mapa(para diminuir as linhas de codigo)
    public void draw(Graphics g2){
        g2.drawImage(image,x,y,w,h,null);
    }
    
    
    public Rectangle getRectangle(){
        return r;
    }
    public void setRectangle(int dx, int dy, int w, int h){
        Rectangle rect = new Rectangle(x,y,w,h);
        r=rect;
    }
    
    public boolean intersects(Rectangle r){
        return this.r.intersects(r);
    }
    public Rectangle intersection(Rectangle r){
        return this.r.intersection(r);
    }
    public void retirarImagem(){
        Rectangle rect = new Rectangle(0,0,0,0);
        image=null;
        r=rect;
        w=0;
        h=0;
    }
 
}
