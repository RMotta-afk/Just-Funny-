/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg.Jogo;

import Classes.*;
import Inimigos.Arael;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.WindowEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import rpg.personagem.Personagem;
/**
 *
 * @author Filhos
 */
public class Iahu extends JFrame {
    //cria-se um personagem aleatorio para usar como parametro no construtor
    //dessa classe
    Personagem g;
    Arael a=new Arael();
    JLabel texto;
        public Iahu(Personagem p){
            g=p;
            initUI(g);
        }
        //construtor vazio para a classe principal poder extender ela
        public Iahu(){
            
        }
        //metodo que cria o painel do jogo
     private void initUI(Personagem P) {
         add(new Board(g,a));

        setTitle("RPG-Neon Genesis Evangelion");
        setSize(575, 700);
        
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /*public static void main(String[] args) {

        EventQueue.invokeLater(() -> {
            Iahu ex = new Iahu();
            ex.setVisible(true);
        });
    }*/
}