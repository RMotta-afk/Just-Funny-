/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg.Jogo;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import rpg.personagem.*;

public class PersonaDoJogador {
    //classe do personagem na tela
    //x e y determinam sua posição inicial
    //w e h são largura e altura da imagem
    //os objetos e inimigos e até o fundo seguirão a mesma ideia

    private int dx;
    private int dy;
    private int x = 40;
    private int y = 60;
    private int w;
    private int h;
    private Image image;
    //o Rectangle é o retangulo da imagem, é com ele que consegue-se fazer a 
    //interação entre as imagens
    private Rectangle r;

    public PersonaDoJogador() {

        loadImage();
         r= new Rectangle(x,y,w,h);

    }
//metodo para carregar a imagem
    private void loadImage() {
        
        ImageIcon ii = new ImageIcon("Imagens/eva01.png");
        image = ii.getImage(); 
        
        w = image.getWidth(null);
        h = image.getHeight(null);
    }
//metodo que faz o personagem mudar de posição sobre a tela
    public void move() {
        
        x += dx;
        y += dy;
        if(x<0||x>520){
            x-=dx;
        }
        if(y<0||y>520){
            y-=dy;
        }
    }
//gets e sets
    public int getX() {
        
        return x;
    }
    public void setX(int X){
        x=X;
    }

    public int getY() {
        
        return y;
    }
    public void setY(int Y){
        y=Y;
    }
    
    public int getWidth() {
        
        return w;
    }
    public void setWidth(int W){
        w=W;
    }
    
    public int getHeight() {
        
        return h;
    }
    public void setHeight(int H){
        h=H;
    }    

    public Image getImage() {
        
        return image;
    }
    public void setimage(Image I){
        image=I;
    }
    //metodo que desenha o personagem no mapa(para diminuir as linhas de codigo)
    public void draw(Graphics g2){
        g2.drawImage(image,x,y,w,h,null);
    }
    
    
    public Rectangle getRectangle(){
        return r;
    }
    public void setRectangle(int dx, int dy, int w, int h){
        Rectangle rect = new Rectangle(x,y,w,h);
        r=rect;
    }
    //o metodo que verifica se o retangulo da imagem interage com o retangulo de 
    //outra imagem
    public boolean intersects(Rectangle r){
        return this.r.intersects(r);
    }
    //metodo que fala onde ocorre a intrerseção(não utilizado no codigo)
    public Rectangle intersection(Rectangle r){
        return this.r.intersection(r);
    }
//metodo que reconhece o pressionamento da tecla e adiciona valores a X e Y
    public void TeclaPressionada(KeyEvent e) {

        int Tecla = e.getKeyCode();

        if (Tecla == KeyEvent.VK_LEFT) {
            dx = -2;
        }

        if (Tecla == KeyEvent.VK_RIGHT) {
            dx = 2;
        }

        if (Tecla == KeyEvent.VK_UP) {
            dy = -2;
        }

        if (Tecla == KeyEvent.VK_DOWN) {
            dy = 2;
        }
    }
//metodo que reconhece ao soltar a tecla para o personagem parar de mover
    public void TeclaSolta(KeyEvent e) {
        
        int Tecla = e.getKeyCode();

        if (Tecla == KeyEvent.VK_LEFT) {
            dx = 0;
        }

        if (Tecla == KeyEvent.VK_RIGHT) {
            dx = 0;
        }

        if (Tecla == KeyEvent.VK_UP) {
            dy = 0;
        }

        if (Tecla == KeyEvent.VK_DOWN) {
            dy = 0;
        }
    }
    
     public void retirarImagem(){
        Rectangle rect = new Rectangle(0,0,0,0);
        image=null;
        r=rect;
        w=0;
        h=0;
    }
}