/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg.Jogo;
import Inimigos.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import rpg.*;
import rpg.personagem.Personagem;
import Itens.PdeCura;
import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
//classe do tabuleiro
public class Board extends JPanel implements ActionListener {
    
    //blocos que foram "descartados" no projeto final que serviriam para definir
    //o tabuleiro, no fim serviram para delimitar o mapa visualmente
    private final int alt_bloco = 28;
    private final int larg_bloco = 28;
    private final int alt_grade = 20;
    private final int larg_grade = 20;
    private PdeCura c;
    private String Placar="<html><body>";
    

    private Timer timer;
    //classe de personagem para definir como funcionará o combate
    private Personagem J;
    private Personagem I;
    //classe batalha onde ocorre o combate
    private Batalha B;
    private TelaFinal T;
    //definição das imagens dos personagens, objetos, fundo e etc.
    private PersonaDoJogador Jogador;
    private PersonaInimigo inimigo, i2, i3;
    private Fundo background;
    private arvores a1,a2,a3,a4,a5,a6,a7;
    private bau bauzin;
    private final int DELAY = 10;
    private int i=0;
    
    //construtor onde recebe dois personagens(um do jogador e o do inimigo)
    //e o metodo para o jogo rodar
    public Board(Personagem p, Personagem a) {
        J=p;
        I=a;
     

        initBoard();
    }
//metodo que adiciona todos os detalhes no tabuleiro
    private void initBoard() {
        addKeyListener(new TAdapter());

	setFocusable(true);
        background= new Fundo();
        inimigo= new PersonaInimigo(280,280);
        i2= new PersonaInimigo(100,400);
        i3= new PersonaInimigo(500,280);
        Jogador = new PersonaDoJogador();
        //os objetos tem suas localizações definidas aq
        a1=new arvores(130,65);
        a2=new arvores(400,450);
        a3=new arvores(100,300);
        a4=new arvores(380,100);
        a5=new arvores(200,200);
        bauzin=new bau(500,500);
        

        //timer que faz o jogo ter um delay e não rodar na velocidade que o computador
        //processaria o jogo normalmente(ultra rapido)
        timer = new Timer(DELAY, this);
        timer.start();
    }
//metodo que integra o desenho que outro metodo faz com as funcionalidades das teclas
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        doDrawing(g);
        drawStatus(g);
       
        
        Toolkit.getDefaultToolkit().sync();
    }
    
    //metodo que desenha todos os componentes adicionados a tela
    private void doDrawing(Graphics g) {
        definirPersona();
        Graphics2D g2d = (Graphics2D) g;
        background.draw(g2d);
        g2d.drawRect(0, 0, larg_grade * larg_bloco, alt_bloco*alt_grade);
         
       a1.draw(g2d);
       a2.draw(g2d);
       a3.draw(g2d);
       a4.draw(g2d);
       a5.draw(g2d);
       bauzin.draw(g2d);
        
        Jogador.draw(g2d);
        inimigo.draw(g2d);
        i2.draw(g2d);
        i3.draw(g2d);
        

    }
    private void drawStatus(Graphics g2d){
        g2d.drawString("Vida:"+J.getVida(), 0, alt_bloco*alt_grade+20);
        g2d.drawString("Nível:"+J.getNível(), 0, alt_bloco*alt_grade+35);
        g2d.drawString("Experiência:"+J.getExp(), 0, alt_bloco*alt_grade+50);
        g2d.drawString("Pontuação:"+J.getPontos(), 0, alt_bloco*alt_grade+65);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        step();
        
    }
    
    //metodo que desenha a "movimentação do personagem" e que detecta as colisões
    private void step() {
        
        Jogador.move();
        
        repaint(Jogador.getX()-1, Jogador.getY()-1, 
                Jogador.getWidth()+2, Jogador.getHeight()+2);
        
        
        inimigo.move();
        repaint(inimigo.getX()-1, inimigo.getY()-1, 
                inimigo.getWidth()+2, inimigo.getHeight()+2);
         Jogador.setRectangle(Jogador.getX(), Jogador.getY(), Jogador.getWidth(), Jogador.getHeight());
         inimigo.setRectangle(inimigo.getX(), inimigo.getY(), inimigo.getWidth(), inimigo.getHeight());
         
         i2.move();
        repaint(i2.getX()-1, i2.getY()-1, 
                i2.getWidth()+2, i2.getHeight()+2);
         i2.setRectangle(i2.getX(), i2.getY(), i2.getWidth(), i2.getHeight());
        
        i3.move();
        repaint(i3.getX()-1, i3.getY()-1, 
                i3.getWidth()+2, i3.getHeight()+2);
         i3.setRectangle(i3.getX(), i3.getY(), i3.getWidth(), i3.getHeight());
        colisao();
        
        
       
    }
//metodo das colisões que faz as verificações e o que fazer caso ocorra
public void colisao(){
    //os objetos como são muito com a msm funcionalidade há um metodo somente
    //pra eles, o que diminui e muito o codigo
    colisaoOB(a1,Jogador);
    colisaoOB(a2,Jogador);
    colisaoOB(a3,Jogador);
    colisaoOB(a4,Jogador);
    colisaoOB(a5,Jogador);
    
    colisaoOBI(a1,inimigo);
    colisaoOBI(a2,inimigo);
    colisaoOBI(a3,inimigo);
    colisaoOBI(a4,inimigo);
    colisaoOBI(a5,inimigo);
    
    colisaoOBI(a1,i2);
    colisaoOBI(a2,i2);
    colisaoOBI(a3,i2);
    colisaoOBI(a4,i2);
    colisaoOBI(a5,i2);
    
    colisaoOBI(a1,i3);
    colisaoOBI(a2,i3);
    colisaoOBI(a3,i3);
    colisaoOBI(a4,i3);
    colisaoOBI(a5,i3);
  
    
        if(Jogador.intersects(inimigo.getRectangle())){
            //System.out.println("isso ai pô");
            //no caso do inimigo chama o metodo de batallha
            B.batalha(J,I);
            if(J.getVida()>0){
                inimigo.retirarImagem();
                J.adicionarPontos(100);
                I.ResetStatus(80, 30);
            }
           
        }
        if(Jogador.intersects(i2.getRectangle())){
            //System.out.println("isso ai pô");
            //no caso do inimigo chama o metodo de batallha
            B.batalha(J,I);
            if(J.getVida()>0){
                i2.retirarImagem();
                J.adicionarPontos(100);
                I.ResetStatus(80, 30);
            }
            
        }
        if(Jogador.intersects(i3.getRectangle())){
            //System.out.println("isso ai pô");
            //no caso do inimigo chama o metodo de batallha
            B.batalha(J,I);
            if(J.getVida()>0){
                i3.retirarImagem();
                J.adicionarPontos(100);
                I.ResetStatus(80, 30);
            }
        }
        if(Jogador.intersects(bauzin.getRectangle())){
            //adicionar ao intergir com o bau o personagem curar a vida
              //System.out.println("isso ai pô");
              c=new PdeCura(J);
              bauzin.retirarImagem();
              System.out.println(J.getVida());
        }
        if(i == 0 && inimigo.getImage()==null && i2.getImage()==null && i3.getImage()==null){
                          J.adicionarPontos(J.getVida()*10);
                          i++;
                          definirPlacar();
                          T=new TelaFinal(0);
        }
        if(J.getVida()<1 && i==0){
            i++;
            Jogador.retirarImagem();
            definirPlacar();
            T=new TelaFinal(1);
            }
    
}
//o metodo de verificação para o personagem não passar por cima do objeto/obstaculo
public void colisaoOB(arvores a, PersonaDoJogador P){
            if(P.intersects(a.getRectangle())){
                //System.out.println("foi");
                if(P.getX()<a.getX()){
                    int dx = P.getX() -2;
                    P.setX(dx);
                }
                if(P.getX()>a.getX()){
                    int dx = P.getX() +2;
                    P.setX(dx);
                }
            
                if(P.getY()<a.getY()){
                int dy=P.getY()-2;
                P.setY(dy);
                }
                if(P.getY()>a.getY()){
                int dy=P.getY()+2;
                P.setY(dy);
                }
    }
}
//função de colisão para o inimigo e os objetos(funcina igualmente o anterior
public void colisaoOBI(arvores a, PersonaInimigo P){
            if(P.intersects(a.getRectangle())){
                //System.out.println("foi");
                if(P.getX()<a.getX()){
                    int dx = P.getX() -2;
                    P.setX(dx);
                }
                if(P.getX()>a.getX()){
                    int dx = P.getX() +2;
                    P.setX(dx);
                }
            
                if(P.getY()<a.getY()){
                int dy=P.getY()-2;
                P.setY(dy);
                }
                if(P.getY()>a.getY()){
                int dy=P.getY()+2;
                P.setY(dy);
                }
    }
}

public void definirPlacar(){
    try {
        FileReader arq = new FileReader("Imagens/placar.txt");
        BufferedReader lerArq = new BufferedReader(arq);
        String linha = lerArq.readLine(); // lê a primeira linha
        while (linha != null) {
            Placar+=linha+"<br>";
            linha = lerArq.readLine(); // lê da segunda até a última linha
        }
        FileWriter arq1 = new FileWriter("Imagens/placar.txt");
        PrintWriter placar = new PrintWriter(arq1);
        Placar  += J.getNome()+"------"+J.getPontos();
        placar.print(Placar);
        arq.close();
        arq1.close();
    } catch (IOException e) {
        System.out.println("Erro na abertura do arquivo:"+ e.getMessage());
    }
}
//metodo que faz com que o personagem do jogo(visualmente) herde as caracteristicas
//do personagem chamado no construtor
public void definirPersona(){
    Jogador.setimage(J.getImage());
    Jogador.setWidth(J.getW());
    Jogador.setHeight(J.getH());
}

   //metodo para reconhecer as teclas
    private class TAdapter extends KeyAdapter {

        @Override
        public void keyReleased(KeyEvent e) {
            Jogador.TeclaSolta(e);
        }

        @Override
        public void keyPressed(KeyEvent e) {
            Jogador.TeclaPressionada(e);
        }
    }
    
   
}