/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg.Jogo;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author Filhos
 */
public class Fundo {
    private int x,y;
    private int w;
    private int h;
    private Image image;
//a classe do fundo define apenas uma imagem que fica atras de todas as outras
    // enquanto o jogo roda
    public Fundo() {

        loadImage();
    }

    private void loadImage() {
        
        ImageIcon ii = new ImageIcon("Imagens/mapa2.png");
        image = ii.getImage(); 
        
        w = image.getWidth(null);
        h = image.getHeight(null);
    }
public int getX() {
        
        return x;
       
    }

    public int getY() {
        
        return y;
    }
    
    public int getWidth() {
        
        return w;
    }
    
    public int getHeight() {
        
        return h;
    }    

    public Image getImage() {
        
        return image;
    }
    public void draw(Graphics g2){
        g2.drawImage(image,x,y,w,h,null);
    }

}
