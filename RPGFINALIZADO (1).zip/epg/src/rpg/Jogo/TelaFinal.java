/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg.Jogo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Filhos
 */
public class TelaFinal extends JFrame {
    JPanel p = new JPanel();
    JButton b = new JButton();
    JLabel imgfundo;
    public TelaFinal(int i){
        p=new JPanel();
        setTitle("RPG-Neon Genesis Evangelion");
        if(i==0){
            imgfundo = new JLabel(new ImageIcon("Imagens/Finalbom.png"));//imagem de fundo
        }
        if(i==1){
            imgfundo = new JLabel(new ImageIcon("Imagens/FINALRUIM.png"));
        }
        imgfundo.setBounds(0,0,575,700);//proporções da imagem
        b = new JButton ("Fim Do Jogo!!");
        b.setBounds(240,500,150,50);
        setSize(575, 700);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setFocusable(true);
        add(b);
        add(imgfundo);
        b.addActionListener(new ActionListener()
        {
 
            @Override
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        });
        
    }
}
