/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg.Jogo;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

/**
 *
 * @author Filhos
 */
public class bau {
    private int x,y;
    private int w;
    private int h;
    private Image image;
    private Rectangle r;

    //os objetos tem a posição definida no construtor para haver varios no mapa
    public bau(int dx, int dy) {
        x=dx;
        y=dy;

        loadImage();
        r= new Rectangle(x,y,w,h);
    }

    private void loadImage() {
        
        ImageIcon ii = new ImageIcon("Imagens/bauzin.png");
        image = ii.getImage(); 
        
        w = image.getWidth(null);
        h = image.getHeight(null);
    }
public int getX() {
        
        return x;
    }

    public int getY() {
        
        return y;
    }
    
    public int getWidth() {
        
        return w;
    }
    
    public int getHeight() {
        
        return h;
    }    

    public Image getImage() {
        
        return image;
    }
    
    public void draw(Graphics g2){
        g2.drawImage(image,x,y,w,h,null);
    }
    
     public Rectangle getRectangle(){
        return r;
    }
    
    public boolean intersects(Rectangle rect){
        return r.intersects(rect);
    }
    public Rectangle intersection(Rectangle rect){
        return r.intersection(rect);
    }
    public void retirarImagem(){
        Rectangle rect = new Rectangle(0,0,0,0);
        image=null;
        r=rect;
        w=0;
        h=0;
    }

}

    

