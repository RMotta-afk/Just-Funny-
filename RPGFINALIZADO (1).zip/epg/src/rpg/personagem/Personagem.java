/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg.personagem;

import java.awt.Image;

/**
 *
 * @author Filhos
 */ //classe abstrata para atribuição dos valores basicos de cada personage,
public abstract class Personagem {
    //definindo as classes essencias para vida, magia,dano de ataque, expeirencia, nível
    int HP,MP,DN, h, w;
    String nome;
    int nivel=1;
    int Exp=0;
    int pontos=0;
    Image i;
    //definindo o construtor ao criar um personagem
    public Personagem(int HP,int MP ,int D){
        this.HP =HP;
        this.MP =MP;
        this.DN =D;
    }
    
    //gets e sets para a aobtenção dos valores do personagem
    public int getVida(){
        return HP;
    }
    public void setVida(int Vida){
        this.HP = Vida;
    }
    
     public int getMagia(){
        return MP;
    }
     
     public void setMagia(int Magia){
        this.MP = Magia;
    }
     
      public int getDano(){
        return DN;
    }
      
      public void setDano(int Dano){
        this.DN = Dano;
    }
      
     
         public int getNível(){
        return nivel;
    }
         public void setNível(int n){
             this.nivel = n;
         }
         
         public String getNome(){
             return nome;
         }
         
         public void setNome(String n){
             this.nome = n;
         }
         
         public int getExp(){
             return Exp;
         }
         //metodo para aumentar o exp ganho
          public void adicionarExp(int e){
             this.Exp += e;
         }
          public int getPontos(){
              return pontos;
          }
          public void adicionarPontos(int p){
              pontos+=p;
          }
          
          public void setImage(Image I){
              i=I;
               w = i.getWidth(null);
               h = i.getHeight(null);
          }
        public Image getImage(){ 
        return i;
     }
        public int getW(){
            return w;
        }
         public int getH(){
            return h;
        }
         public void ResetStatus(int a, int b){
        this.setVida(a);
        this.setMagia(b);
    }
    
    
}
