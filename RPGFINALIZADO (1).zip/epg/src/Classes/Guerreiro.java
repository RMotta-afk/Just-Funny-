/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.awt.Image;
import javax.swing.ImageIcon;
import rpg.personagem.Personagem;

/**
 *
 * @author Filhos
 */
public class Guerreiro extends Personagem {
    //cada personagem terá o nome único e a imagem dele associada
    Image Gue=new ImageIcon("Imagens/eva01.png").getImage();
    public Guerreiro(){
        super(100,20,25);
        setImage(Gue);
    }

}
