/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.awt.Image;
import javax.swing.ImageIcon;
import rpg.personagem.Personagem;

public class Mago extends Personagem{
    //cada personagem terá o nome único e a imagem dele associada
    Image Mag=new ImageIcon("Imagens/eva0.png").getImage();
     public Mago(){
        super(60,50,20);
        setImage(Mag);
    }
    
}
