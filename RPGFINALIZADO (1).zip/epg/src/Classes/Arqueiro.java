/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.awt.Image;
import javax.swing.ImageIcon;
import rpg.personagem.Personagem;

/**
 *
 * @author Filhos
 */
public class Arqueiro extends Personagem{
    //cada personagem terá o nome único e a imagem dele associada
    Image Arq=new ImageIcon("Imagens/eva02.png").getImage();
     public Arqueiro(){
        super(80,30,15);
        setImage(Arq);
    }
     
     
     
}

