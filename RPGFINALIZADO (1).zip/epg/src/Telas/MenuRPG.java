package Telas;

import Classes.*;
import rpg.personagem.Personagem;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.reflect.Array.set;
import java.util.Scanner;
import javax.swing.ImageIcon;
import javax.swing.JTextField; 
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import rpg.Jogo.Iahu;

public class MenuRPG extends Iahu {
    Guerreiro G=new Guerreiro();
    Arqueiro A=new Arqueiro();
    Mago M=new Mago();

    // Declara componentes

    JLabel texto;
    Scanner nome = new Scanner(System.in);
    String placar="<html><body>";
    
    // Cria o menu completo
    public JMenuBar criaMenu()
            
            
    {
       
        // Declara componentes do menu genericamente
        JMenuBar barraMenu;
        JMenu menu;
        JMenu submenu;
        JMenuItem menuItem;
 
        // Cria barra do Menu
        barraMenu = new JMenuBar();
 
        // Cria menu
        menu = new JMenu("Iniciar!!");
 
        // Adiciona menu a barra
        barraMenu.add(menu);
 
        // Cria item do menu
        menuItem = new JMenuItem("EVA00", KeyEvent.VK_I);
 
        // Cria evento do item
        menuItem.addActionListener(new ActionListener()
        {
 
            @Override
            public void actionPerformed(ActionEvent e)
            {
                System.out.print("Digite o nome desejado aqui:");
                M.setNome(nome.next());
              EventQueue.invokeLater(() -> {
            Iahu ex = new Iahu(M);
            ex.setVisible(true);
            });
               setVisible(true);
 
            }
        });
 
        // Adiciona item ao Menu
        menu.add(menuItem);
 
        // Repete processo para o segundo item
        menuItem = new JMenuItem("EVA01", KeyEvent.VK_T);
        menuItem.addActionListener(new ActionListener()
        {
 
            @Override
            public void actionPerformed(ActionEvent e)
            {
                System.out.print("Digite o nome desejado aqui:");
                G.setNome(nome.next());
               EventQueue.invokeLater(() -> {
                Iahu ex = new Iahu(G);
                ex.setVisible(true);
                });
               setVisible(true);
 
            }
        });
 
        menu.add(menuItem);
 
        // Repete processo para o terceiro item
        menuItem = new JMenuItem("EVA02", KeyEvent.VK_E);
        menuItem.addActionListener(new ActionListener()
        {
 
            @Override
            public void actionPerformed(ActionEvent e)
            {   
                System.out.print("Digite o nome desejado aqui:");
                A.setNome(nome.next());
               EventQueue.invokeLater(() -> {
                Iahu ex = new Iahu(A);
                ex.setVisible(true);
                });
               setVisible(true);
 
            }
        });
        menu.add(menuItem);
 
        // Adiciona um separador de menu
        menu.addSeparator();
 
        // Repete processo para o quarto item
        menuItem = new JMenuItem("Placar", KeyEvent.VK_M);
        menuItem.addActionListener(new ActionListener()
        {
 
            @Override
            public void actionPerformed(ActionEvent e)
            {
               
    try {
      FileReader arq = new FileReader("Imagens/placar.txt");
      BufferedReader lerArq = new BufferedReader(arq);

      String linha = lerArq.readLine(); // lê a primeira linha
      while (linha != null) {
          placar+=linha+"<br>";
        linha = lerArq.readLine(); // lê da segunda até a última linha
      }
      texto.setText(placar);

      arq.close();
    } catch (IOException a) {
        System.out.println("Erro na abertura do arquivo:"+ a.getMessage());
    }
 
            }
        });
        menu.add(menuItem);

 
        // Cria um segundo menu
        menu = new JMenu("Sobre o Jogo");
 
        // Cria item para o segundo menu e seu evento
        menuItem = new JMenuItem("História", KeyEvent.VK_D);
        menuItem.addActionListener(new ActionListener()
        {
 
            @Override
            public void actionPerformed(ActionEvent e)
            {
            texto.setText("<html><body><font color=\"red\">História do Jogo:</font><br><br>O nosso projeto de RPG é baseado na série de animação japonesa 'Evangelion' transmitido entre 4 de outubro de 1995 a 27 de março de 1996.<br><br>O jogo passa quinze anos após um cataclismo mundial, particularmente na futurística cidade fortificada de Tóquio-3. Temos como objetivo controlar uma das 3 biomáquinas chamado 'EVA', eliminar os Inimigos considerados 'Anjos' para impedir um possível apocalipse.");
                
                
 
            }
        });
 
        // Adiciona item ao menu
        menu.add(menuItem);
        

        menuItem = new JMenuItem("Desenvolvedores", KeyEvent.VK_D);
        menuItem.addActionListener(new ActionListener()
        {
 
            @Override
            public void actionPerformed(ActionEvent e)
            {
                texto.setText("<html><body><font color=\"red\"> Desenvolvedores:</font><br><br>    Anne Caroline Coutinho de Souza;<br>  Enrique Augusto Ortega de Souza;<br>    Heloísa Carla Lins de Araujo Belchior;<br>   Raphael Lopes Motta;");  

 
            }
        });
        
        menu.add(menuItem);
        
        menuItem = new JMenuItem("Instruções", KeyEvent.VK_D);
        menuItem.addActionListener(new ActionListener()
        {
 
            @Override
            public void actionPerformed(ActionEvent e)
            {
                texto.setText("<html><body><font color=\"red\"> Instruções:</font><br><br><font color=\"red\"> Como roda:</font> A tela aparecerá com o personagem escolhido e os inimigos, vá até eles para iniciar o combate. <br><font color=\"red\"> Controles:</font> setas do teclado movem o personagem <br><font color=\"red\"> Combate:</font> O combate, sem interface grafica, ocorre no terminal de comandos do NetBeans, onde printa as informações necessarias. <br><font color=\"red\">Ataques:</font> 1 para golpe normal; 2 para golpe especial<br><font color=\"red\"> Objetivo:</font> Enfrentar todos os inimigos da tela e terminar vivo! <br>    ");

 
            }
        });
        menu.add(menuItem);
 
        // Adiciona menu a barra de menus
        barraMenu.add(menu);
        
        //Adiciona o ultimo menu
        menu = new JMenu("Sair do Jogo");
 
        // Cria item para o segundo menu e seu evento
        menuItem = new JMenuItem("Sair", KeyEvent.VK_D);
        menuItem.addActionListener(new ActionListener()
        {
 
            @Override
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
            }
        });
 
        // Adiciona item ao menu
        menu.add(menuItem);
        // Adiciona menu a barra de menus
        barraMenu.add(menu);



 
        // retorna menu completo
        return barraMenu;
 
    }
 
    // Cria um painel
    public Container criaPainel()
    {
        // Cria painel e suas propriedades
        JPanel painel = new JPanel(new BorderLayout());
        painel.setOpaque(true);
        
 
        // Cria um componente de texto
        texto = new JLabel();
 
        // Adiciona componente ao painel
        painel.add(texto, BorderLayout.PAGE_START);
        
 
        /// Retorna Painel
        return painel;
    }
    
    
    // Cria GUI
    public static void criaGUI()
    {
        // Cria formulario e suas propriedades
        JFrame formulario = new JFrame("Neon Genesis Evangelion - rpg");
        formulario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        // Cria Menu
        MenuRPG menu = new MenuRPG();
 
        // Adiciona barra de menus na GUI
        formulario.setJMenuBar(menu.criaMenu());
 
        // Adiciona painel na GUI
        formulario.setContentPane(menu.criaPainel());
 
        // Adiciona propriedades ao formulario
        JLabel imagemfundo = new JLabel(new ImageIcon("Imagens/CAPAAA.png"));//imagem de fundo
        imagemfundo.setBounds(0,0,575,700);//proporções da imagem
        formulario.add(imagemfundo);
        formulario.setSize(575, 700);
        formulario.setVisible(true);   
        formulario.setResizable(false);
 
    }
 
    public static void main(String[] args)
    {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
 
            @Override
            public void run()
            {
 
                // Monta GUI
                criaGUI();
            }
        });
 
    }
 
}
   
    

